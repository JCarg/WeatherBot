﻿$(document).ready(function () {
    $('#weatherTable').DataTable({
        paging: false,
        searching: false,
        info: false
    });
});