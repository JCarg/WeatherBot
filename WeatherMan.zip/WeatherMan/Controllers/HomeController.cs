﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using System.Xml;

namespace WeatherMan.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            //Api Data retrieval in Xml to Html
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(
                $"https://api.openweathermap.org/data/2.5/weather?q=Cleveland&mode=xml&appid=b6907d289e10d714a6e88b30761fae22");
            XmlReader xmlReader = new XmlNodeReader(xmlDoc.LastChild.ChildNodes[0]);
            DataSet ds = new DataSet();
            List<SelectListItem> nodeNames = RetrieveNodeNames(xmlDoc.ChildNodes);

            ds.ReadXml(xmlReader);
            
            ViewData["WeatherData"] = ConvertDataTableToHTML(ds.Tables[0]);
            ViewData["NodeList"] = nodeNames;
            return View();
        }
        [HttpPost]
        public ActionResult Index( string location, string node )
        {
            if(location == null)
            {
                location = "Cleveland";
            }
           
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(
                $"https://api.openweathermap.org/data/2.5/weather?q={location}&mode=xml&appid=b6907d289e10d714a6e88b30761fae22");
            XmlReader xmlReader = new XmlNodeReader(xmlDoc.LastChild.ChildNodes[int.Parse(node)]);
            DataSet ds = new DataSet();
            List<SelectListItem> nodeNames = RetrieveNodeNames(xmlDoc.ChildNodes);

            ds.ReadXml(xmlReader);
            ViewBag.Location = location;
            ViewData["WeatherData"] = ConvertDataTableToHTML(ds.Tables[0]);
            ViewData["NodeList"] = nodeNames;
            return View();
        }


        public static string ConvertDataTableToHTML( DataTable dt )
        {
            string html = $"<table id=\"weatherTable\" class=\"display\" >";
            //Header Row
            html += "<thead><tr>";
            for(int i = 0; i < dt.Columns.Count; i++)
                html += "<td>" + dt.Columns[i].ColumnName + "</td>";
            html += "</tr></thead>";
            //Body Rows
            html += "<tbody>";
            for(int i = 0; i < dt.Rows.Count; i++)
            {
                html += "<tr>";
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    html += "<td>" + dt.Rows[i][j].ToString() + "</td>";
                }
                html += "</tr>";
            }
            html += "</tbody></table>";
            return html;
        }

        public static List<SelectListItem> RetrieveNodeNames(XmlNodeList nodes)
        {
            List<SelectListItem> nodeNames=new List<SelectListItem>();
            int i = 0;
            foreach (XmlNode node in nodes[1].ChildNodes)
            {
               nodeNames.Add(new SelectListItem{Text=node.Name,Value = i.ToString()});
                i++;
            }
            return nodeNames;
        }
    }
}